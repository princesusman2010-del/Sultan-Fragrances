import { useState, useEffect, useCallback, ReactNode } from "react";
import sultanHero from "@/imports/SULTAN_FRAGRANCES.png";
import sultanBottle from "@/imports/SULTAN_FRAGRANCE_.png";

/* ── Scroll reveal ── */
function useReveal() {
  useEffect(() => {
    const run = () => {
      document.querySelectorAll(".reveal").forEach((el) => {
        const rect = el.getBoundingClientRect();
        if (rect.top < window.innerHeight * 0.88) el.classList.add("visible");
      });
    };
    run();
    window.addEventListener("scroll", run, { passive: true });
    return () => window.removeEventListener("scroll", run);
  });
}

function Reveal({ children, className = "", variant = "" }: { children: ReactNode; className?: string; variant?: string }) {
  return <div className={`reveal ${variant} ${className}`}>{children}</div>;
}

function GoldDivider() {
  return (
    <div className="flex items-center justify-center my-4">
      <div className="h-px w-20" style={{ background: "linear-gradient(90deg,transparent,#C9922A)" }} />
      <span className="px-3 text-xs" style={{ color: "#C9922A" }}>✦</span>
      <div className="h-px w-20" style={{ background: "linear-gradient(90deg,#C9922A,transparent)" }} />
    </div>
  );
}

/* ── Types ── */
interface Product {
  id: number; name: string; type: string; notes: string;
  family: string; price: string; priceNum: number;
  img: string; badge: string | null; description: string;
  topNotes: string[]; heartNotes: string[]; baseNotes: string[];
  sizes: string[];
}

interface CartItem { product: Product; qty: number; size: string; }

/* ── Products ── */
const products: Product[] = [
  {
    id: 1, name: "Dior Sauvage", type: "Impression Of",
    notes: "Bergamot · Ambroxan · Cedar", family: "Fresh Aromatic",
    price: "PKR 1,800", priceNum: 1800,
    img: "https://images.unsplash.com/photo-1760860992203-85ca32536788?w=600&h=700&fit=crop&auto=format",
    badge: "Bestseller",
    description: "A raw and noble freshness. Wild and rocky lands. Sun-parched wood. A perfume that radiates with confidence and vitality.",
    topNotes: ["Bergamot", "Pepper"], heartNotes: ["Lavender", "Pink Pepper"], baseNotes: ["Ambroxan", "Cedar", "Labdanum"],
    sizes: ["30ml", "50ml", "100ml"],
  },
  {
    id: 2, name: "Bleu de Chanel", type: "Impression Of",
    notes: "Citrus · Ginger · Incense", family: "Woody Aromatic",
    price: "PKR 1,800", priceNum: 1800,
    img: "https://images.unsplash.com/photo-1737920459846-2d0318700658?w=600&h=700&fit=crop&auto=format",
    badge: null,
    description: "An ode to masculine freedom. A woody, aromatic fragrance for the man who defies convention and radiates quiet confidence.",
    topNotes: ["Grapefruit", "Lemon", "Mint"], heartNotes: ["Ginger", "Melon", "Nutmeg"], baseNotes: ["Incense", "Vetiver", "Cedar"],
    sizes: ["30ml", "50ml", "100ml"],
  },
  {
    id: 3, name: "Oud Wood", type: "Impression Of",
    notes: "Oud · Sandalwood · Vetiver", family: "Oriental Woody",
    price: "PKR 2,200", priceNum: 2200,
    img: "https://images.unsplash.com/photo-1774682060997-f8959850a7d4?w=600&h=700&fit=crop&auto=format",
    badge: "Premium",
    description: "Rare oud wood is blended with sandalwood, rosewood, and vetiver for a rich, warm oriental signature.",
    topNotes: ["Oud", "Rosewood"], heartNotes: ["Cardamom", "Sandalwood"], baseNotes: ["Vetiver", "Tonka Bean", "Amber"],
    sizes: ["30ml", "50ml"],
  },
  {
    id: 4, name: "Creed Aventus", type: "Impression Of",
    notes: "Pineapple · Birch · Musk", family: "Fruity Chypre",
    price: "PKR 2,000", priceNum: 2000,
    img: "https://images.unsplash.com/photo-1774682061055-3bfe402e5a12?w=600&h=700&fit=crop&auto=format",
    badge: null,
    description: "Celebrating strength, power, and success. A bold fruity-woody chypre that leaves a lasting impression.",
    topNotes: ["Pineapple", "Bergamot", "Apple"], heartNotes: ["Rose", "Dry Birch", "Patchouli"], baseNotes: ["Musk", "Oak Moss", "Ambergris"],
    sizes: ["30ml", "50ml", "100ml"],
  },
  {
    id: 5, name: "La Nuit de L'Homme", type: "Impression Of",
    notes: "Cardamom · Cedarwood · Vetiver", family: "Oriental Fougère",
    price: "PKR 1,800", priceNum: 1800,
    img: "https://images.unsplash.com/photo-1725138804277-3216924a8f5c?w=600&h=700&fit=crop&auto=format",
    badge: null,
    description: "A powerful, sensual evening fragrance. Dark, mysterious, unforgettable — for the man who commands any room.",
    topNotes: ["Cardamom", "Bergamot"], heartNotes: ["Lavender", "Caraway"], baseNotes: ["Cedarwood", "Vetiver", "Coumarin"],
    sizes: ["30ml", "50ml", "100ml"],
  },
  {
    id: 6, name: "Black Opium", type: "Impression Of",
    notes: "Coffee · Vanilla · White Florals", family: "Gourmand Floral",
    price: "PKR 1,800", priceNum: 1800,
    img: "https://images.unsplash.com/photo-1774682060967-15d73fd5e1b5?w=600&h=700&fit=crop&auto=format",
    badge: "New",
    description: "An addictive blend of coffee and white flowers. Bold, feminine, and intoxicating — impossible to ignore.",
    topNotes: ["Pink Pepper", "Orange Blossom", "Pear"], heartNotes: ["Coffee", "Jasmine"], baseNotes: ["Vanilla", "Patchouli", "Cedar"],
    sizes: ["30ml", "50ml", "100ml"],
  },
];

const filters = ["All", "Fresh Aromatic", "Woody Aromatic", "Oriental Woody", "Gourmand Floral", "Fruity Chypre", "Oriental Fougère"];

/* ═══════════════════════════════════════
   PRODUCT DETAIL MODAL
═══════════════════════════════════════ */
function ProductModal({ product, onClose, onAddToCart }: {
  product: Product; onClose: () => void;
  onAddToCart: (p: Product, qty: number, size: string) => void;
}) {
  const [qty, setQty] = useState(1);
  const [size, setSize] = useState(product.sizes[1] || product.sizes[0]);
  const [added, setAdded] = useState(false);

  const handleAdd = () => {
    onAddToCart(product, qty, size);
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: "rgba(0,0,0,0.75)", backdropFilter: "blur(6px)" }} onClick={onClose}>
      <div className="modal-enter relative w-full max-w-3xl max-h-[90vh] overflow-y-auto" style={{ background: "#110E0A", border: "1px solid rgba(201,146,42,0.3)" }} onClick={(e) => e.stopPropagation()}>
        <button onClick={onClose} className="absolute top-4 right-4 z-10 w-8 h-8 flex items-center justify-center transition-colors" style={{ color: "#9C8860" }}
          onMouseEnter={e => (e.currentTarget as HTMLElement).style.color = "#C9922A"}
          onMouseLeave={e => (e.currentTarget as HTMLElement).style.color = "#9C8860"}>
          <svg width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path strokeLinecap="round" d="M6 18L18 6M6 6l12 12" /></svg>
        </button>

        <div className="grid md:grid-cols-2">
          {/* Image */}
          <div className="relative h-72 md:h-auto" style={{ background: "#1C1710", minHeight: "300px" }}>
            <img src={product.img} alt={product.name} className="w-full h-full object-cover" />
            <div className="absolute inset-0" style={{ background: "linear-gradient(to top, rgba(17,14,10,0.6) 0%, transparent 50%)" }} />
            {product.badge && (
              <div className="absolute top-4 left-4 font-cinzel text-[10px] tracking-widest uppercase px-3 py-1" style={{ background: "#C9922A", color: "#09080A" }}>{product.badge}</div>
            )}
          </div>

          {/* Info */}
          <div className="p-7 flex flex-col gap-5">
            <div>
              <p className="font-cinzel text-[10px] tracking-widest uppercase mb-1" style={{ color: "#8B6214" }}>{product.type}</p>
              <h2 className="font-cinzel font-black text-2xl tracking-wide" style={{ color: "#F0E6C8" }}>{product.name}</h2>
              <p className="text-xs mt-1 italic" style={{ color: "#9C8860" }}>{product.family}</p>
            </div>

            <p className="text-sm leading-relaxed" style={{ color: "#C8B896" }}>{product.description}</p>

            {/* Notes */}
            <div className="grid grid-cols-3 gap-3">
              {[
                { label: "Top", notes: product.topNotes },
                { label: "Heart", notes: product.heartNotes },
                { label: "Base", notes: product.baseNotes },
              ].map(n => (
                <div key={n.label} className="p-3" style={{ background: "#1C1710", border: "1px solid rgba(201,146,42,0.12)" }}>
                  <p className="font-cinzel text-[9px] tracking-widest uppercase mb-2" style={{ color: "#C9922A" }}>{n.label}</p>
                  {n.notes.map(note => <p key={note} className="text-xs" style={{ color: "#9C8860" }}>{note}</p>)}
                </div>
              ))}
            </div>

            {/* Size */}
            <div>
              <p className="font-cinzel text-[10px] tracking-widest uppercase mb-2" style={{ color: "#9C8860" }}>Size</p>
              <div className="flex gap-2">
                {product.sizes.map(s => (
                  <button key={s} onClick={() => setSize(s)}
                    className="font-cinzel text-xs tracking-wide px-4 py-2 transition-all"
                    style={{ border: "1px solid", borderColor: size === s ? "#C9922A" : "rgba(201,146,42,0.25)", background: size === s ? "#C9922A" : "transparent", color: size === s ? "#09080A" : "#9C8860" }}>
                    {s}
                  </button>
                ))}
              </div>
            </div>

            {/* Qty + price */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <button onClick={() => setQty(q => Math.max(1, q - 1))} className="w-8 h-8 flex items-center justify-center transition-colors" style={{ border: "1px solid rgba(201,146,42,0.3)", color: "#C9922A" }}>−</button>
                <span className="font-cinzel text-lg" style={{ color: "#F0E6C8" }}>{qty}</span>
                <button onClick={() => setQty(q => q + 1)} className="w-8 h-8 flex items-center justify-center transition-colors" style={{ border: "1px solid rgba(201,146,42,0.3)", color: "#C9922A" }}>+</button>
              </div>
              <span className="font-cinzel font-bold text-xl gold-shimmer">PKR {(product.priceNum * qty).toLocaleString()}</span>
            </div>

            <button onClick={handleAdd}
              className="w-full font-cinzel text-xs tracking-widest uppercase py-3 transition-all duration-200"
              style={{ background: added ? "#2A5A1A" : "#C9922A", color: added ? "#90E870" : "#09080A" }}>
              {added ? "✓ Added to Cart" : "Add to Cart"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════
   CART PANEL
═══════════════════════════════════════ */
function CartPanel({ items, onClose, onUpdate, onCheckout }: {
  items: CartItem[]; onClose: () => void;
  onUpdate: (id: number, size: string, qty: number) => void;
  onCheckout: () => void;
}) {
  const total = items.reduce((s, i) => s + i.product.priceNum * i.qty, 0);

  return (
    <div className="fixed inset-0 z-50 flex justify-end" style={{ background: "rgba(0,0,0,0.6)", backdropFilter: "blur(4px)" }} onClick={onClose}>
      <div className="cart-panel relative w-full max-w-sm h-full flex flex-col" style={{ background: "#110E0A", borderLeft: "1px solid rgba(201,146,42,0.25)" }} onClick={e => e.stopPropagation()}>
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5" style={{ borderBottom: "1px solid rgba(201,146,42,0.15)" }}>
          <div>
            <h3 className="font-cinzel font-bold text-base tracking-widest uppercase" style={{ color: "#F0E6C8" }}>Your Cart</h3>
            <p className="font-cinzel text-xs" style={{ color: "#9C8860" }}>{items.length} item{items.length !== 1 ? "s" : ""}</p>
          </div>
          <button onClick={onClose} style={{ color: "#9C8860" }}>
            <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path strokeLinecap="round" d="M6 18L18 6M6 6l12 12" /></svg>
          </button>
        </div>

        {/* Items */}
        <div className="flex-1 overflow-y-auto px-6 py-4 flex flex-col gap-4">
          {items.length === 0 && (
            <div className="flex flex-col items-center justify-center h-full gap-4 opacity-50">
              <svg width="48" height="48" fill="none" stroke="#C9922A" strokeWidth="1.5" viewBox="0 0 24 24"><path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4zM3 6h18M16 10a4 4 0 01-8 0"/></svg>
              <p className="font-cinzel text-sm tracking-widest uppercase" style={{ color: "#9C8860" }}>Cart is empty</p>
            </div>
          )}
          {items.map(item => (
            <div key={`${item.product.id}-${item.size}`} className="flex gap-3" style={{ borderBottom: "1px solid rgba(201,146,42,0.1)", paddingBottom: "16px" }}>
              <img src={item.product.img} alt={item.product.name} className="w-16 h-16 object-cover flex-shrink-0" style={{ border: "1px solid rgba(201,146,42,0.2)" }} />
              <div className="flex-1 min-w-0">
                <p className="font-cinzel text-sm font-bold truncate" style={{ color: "#F0E6C8" }}>{item.product.name}</p>
                <p className="font-cinzel text-xs" style={{ color: "#8B6214" }}>{item.size}</p>
                <div className="flex items-center justify-between mt-2">
                  <div className="flex items-center gap-2">
                    <button onClick={() => onUpdate(item.product.id, item.size, item.qty - 1)} className="w-6 h-6 flex items-center justify-center text-xs" style={{ border: "1px solid rgba(201,146,42,0.3)", color: "#C9922A" }}>−</button>
                    <span className="font-cinzel text-xs" style={{ color: "#F0E6C8" }}>{item.qty}</span>
                    <button onClick={() => onUpdate(item.product.id, item.size, item.qty + 1)} className="w-6 h-6 flex items-center justify-center text-xs" style={{ border: "1px solid rgba(201,146,42,0.3)", color: "#C9922A" }}>+</button>
                  </div>
                  <span className="font-cinzel text-sm font-bold" style={{ color: "#C9922A" }}>PKR {(item.product.priceNum * item.qty).toLocaleString()}</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Footer */}
        {items.length > 0 && (
          <div className="px-6 py-5" style={{ borderTop: "1px solid rgba(201,146,42,0.15)" }}>
            <div className="flex justify-between mb-4">
              <span className="font-cinzel text-sm tracking-widest uppercase" style={{ color: "#9C8860" }}>Total</span>
              <span className="font-cinzel font-bold text-lg gold-shimmer">PKR {total.toLocaleString()}</span>
            </div>
            <button onClick={onCheckout} className="w-full font-cinzel text-xs tracking-widest uppercase py-3 transition-all duration-200"
              style={{ background: "#C9922A", color: "#09080A" }}
              onMouseEnter={e => (e.currentTarget as HTMLElement).style.background = "#E8B84B"}
              onMouseLeave={e => (e.currentTarget as HTMLElement).style.background = "#C9922A"}>
              Proceed to Checkout
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════
   CHECKOUT MODAL
═══════════════════════════════════════ */
function CheckoutModal({ items, onClose, onSuccess }: {
  items: CartItem[]; onClose: () => void; onSuccess: () => void;
}) {
  const total = items.reduce((s, i) => s + i.product.priceNum * i.qty, 0);
  const [step, setStep] = useState<"details" | "payment" | "confirm">("details");
  const [payment, setPayment] = useState<"cod" | "advance">("cod");
  const [screenshot, setScreenshot] = useState<File | null>(null);
  const [screenshotPreview, setScreenshotPreview] = useState<string | null>(null);
  const [form, setForm] = useState({ name: "", phone: "", address: "", city: "" });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validate = () => {
    const e: Record<string, string> = {};
    if (!form.name.trim()) e.name = "Name is required";
    if (!/^03\d{9}$/.test(form.phone)) e.phone = "Enter valid Pakistani mobile number (03XXXXXXXXX)";
    if (!form.address.trim()) e.address = "Address is required";
    if (!form.city.trim()) e.city = "City is required";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleScreenshot = (file: File | null) => {
    setScreenshot(file);
    if (file) {
      const reader = new FileReader();
      reader.onload = e => setScreenshotPreview(e.target?.result as string);
      reader.readAsDataURL(file);
    } else {
      setScreenshotPreview(null);
    }
  };

  const handleSubmit = () => {
    if (step === "details") {
      if (validate()) setStep("payment");
    } else if (step === "payment") {
      if (payment === "advance" && !screenshot) {
        setErrors({ screenshot: "Please upload your EasyPaisa payment screenshot" });
        return;
      }
      setErrors({});
      setStep("confirm");
    }
  };

  const inputStyle = (field: string) => ({
    background: "#1C1710",
    border: `1px solid ${errors[field] ? "#E05A5A" : "rgba(201,146,42,0.25)"}`,
    color: "#F0E6C8",
    outline: "none",
    width: "100%",
    padding: "10px 14px",
    fontFamily: "'Raleway', sans-serif",
    fontSize: "13px",
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: "rgba(0,0,0,0.8)", backdropFilter: "blur(8px)" }} onClick={onClose}>
      <div className="modal-enter relative w-full max-w-lg max-h-[92vh] overflow-y-auto" style={{ background: "#110E0A", border: "1px solid rgba(201,146,42,0.3)" }} onClick={e => e.stopPropagation()}>
        <button onClick={onClose} className="absolute top-4 right-4 z-10" style={{ color: "#9C8860" }}>
          <svg width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path strokeLinecap="round" d="M6 18L18 6M6 6l12 12" /></svg>
        </button>

        <div className="p-7">
          {/* Steps indicator */}
          <div className="flex items-center gap-2 mb-8">
            {(["details", "payment", "confirm"] as const).map((s, i) => (
              <div key={s} className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-full flex items-center justify-center font-cinzel text-xs font-bold"
                  style={{ background: step === s || (i < ["details","payment","confirm"].indexOf(step)) ? "#C9922A" : "rgba(201,146,42,0.2)", color: step === s || (i < ["details","payment","confirm"].indexOf(step)) ? "#09080A" : "#9C8860" }}>
                  {i + 1}
                </div>
                <span className="font-cinzel text-[10px] tracking-widest uppercase" style={{ color: step === s ? "#C9922A" : "#4A3D28" }}>
                  {s === "details" ? "Details" : s === "payment" ? "Payment" : "Confirm"}
                </span>
                {i < 2 && <div className="h-px w-6" style={{ background: "rgba(201,146,42,0.2)" }} />}
              </div>
            ))}
          </div>

          {/* ── STEP 1: Details ── */}
          {step === "details" && (
            <div className="flex flex-col gap-5">
              <h3 className="font-cinzel font-bold text-lg tracking-widest uppercase" style={{ color: "#F0E6C8" }}>Delivery Details</h3>
              <GoldDivider />
              {[
                { key: "name", label: "Full Name", placeholder: "e.g. Ahmed Khan" },
                { key: "phone", label: "Phone Number", placeholder: "03XXXXXXXXX" },
                { key: "address", label: "Street Address", placeholder: "House #, Street, Area" },
                { key: "city", label: "City", placeholder: "e.g. Lahore, Karachi, Islamabad" },
              ].map(f => (
                <div key={f.key}>
                  <label className="font-cinzel text-[10px] tracking-widest uppercase block mb-1" style={{ color: "#9C8860" }}>{f.label}</label>
                  <input
                    style={inputStyle(f.key)}
                    placeholder={f.placeholder}
                    value={(form as any)[f.key]}
                    onChange={e => setForm(v => ({ ...v, [f.key]: e.target.value }))}
                  />
                  {errors[f.key] && <p className="text-xs mt-1" style={{ color: "#E05A5A" }}>{errors[f.key]}</p>}
                </div>
              ))}

              {/* Order summary */}
              <div className="mt-2" style={{ background: "#1C1710", border: "1px solid rgba(201,146,42,0.15)", padding: "16px" }}>
                <p className="font-cinzel text-[10px] tracking-widest uppercase mb-3" style={{ color: "#9C8860" }}>Order Summary</p>
                {items.map(i => (
                  <div key={`${i.product.id}-${i.size}`} className="flex justify-between mb-2">
                    <span className="text-xs" style={{ color: "#C8B896" }}>{i.product.name} ({i.size}) × {i.qty}</span>
                    <span className="font-cinzel text-xs font-bold" style={{ color: "#C9922A" }}>PKR {(i.product.priceNum * i.qty).toLocaleString()}</span>
                  </div>
                ))}
                <div className="flex justify-between mt-3 pt-3" style={{ borderTop: "1px solid rgba(201,146,42,0.2)" }}>
                  <span className="font-cinzel text-xs tracking-widest uppercase" style={{ color: "#9C8860" }}>Total</span>
                  <span className="font-cinzel font-bold text-sm gold-shimmer">PKR {total.toLocaleString()}</span>
                </div>
              </div>

              <button onClick={handleSubmit} className="w-full font-cinzel text-xs tracking-widest uppercase py-3 transition-all"
                style={{ background: "#C9922A", color: "#09080A" }}
                onMouseEnter={e => (e.currentTarget as HTMLElement).style.background = "#E8B84B"}
                onMouseLeave={e => (e.currentTarget as HTMLElement).style.background = "#C9922A"}>
                Continue to Payment →
              </button>
            </div>
          )}

          {/* ── STEP 2: Payment ── */}
          {step === "payment" && (
            <div className="flex flex-col gap-5">
              <h3 className="font-cinzel font-bold text-lg tracking-widest uppercase" style={{ color: "#F0E6C8" }}>Payment Method</h3>
              <GoldDivider />

              {/* COD */}
              <div onClick={() => setPayment("cod")} className="cursor-pointer p-5 transition-all"
                style={{ border: `1px solid ${payment === "cod" ? "#C9922A" : "rgba(201,146,42,0.2)"}`, background: payment === "cod" ? "rgba(201,146,42,0.08)" : "#1C1710" }}>
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-4 h-4 rounded-full border-2 flex items-center justify-center" style={{ borderColor: "#C9922A" }}>
                    {payment === "cod" && <div className="w-2 h-2 rounded-full" style={{ background: "#C9922A" }} />}
                  </div>
                  <p className="font-cinzel text-sm font-bold tracking-wide" style={{ color: "#F0E6C8" }}>Cash on Delivery</p>
                </div>
                <p className="text-xs ml-7 leading-relaxed" style={{ color: "#9C8860" }}>Pay when your order arrives at your doorstep. Available across Pakistan.</p>
              </div>

              {/* EasyPaisa */}
              <div onClick={() => setPayment("advance")} className="cursor-pointer p-5 transition-all"
                style={{ border: `1px solid ${payment === "advance" ? "#C9922A" : "rgba(201,146,42,0.2)"}`, background: payment === "advance" ? "rgba(201,146,42,0.08)" : "#1C1710" }}>
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-4 h-4 rounded-full border-2 flex items-center justify-center" style={{ borderColor: "#C9922A" }}>
                    {payment === "advance" && <div className="w-2 h-2 rounded-full" style={{ background: "#C9922A" }} />}
                  </div>
                  <p className="font-cinzel text-sm font-bold tracking-wide" style={{ color: "#F0E6C8" }}>Advance Payment — EasyPaisa</p>
                </div>
                <p className="text-xs ml-7 leading-relaxed" style={{ color: "#9C8860" }}>Pay in advance via EasyPaisa and get priority dispatch.</p>

                {payment === "advance" && (
                  <div className="ml-7 mt-4 flex flex-col gap-4">
                    {/* EasyPaisa details */}
                    <div className="p-4" style={{ background: "rgba(201,146,42,0.12)", border: "1px solid rgba(201,146,42,0.3)" }}>
                      <p className="font-cinzel text-[10px] tracking-widest uppercase mb-2" style={{ color: "#C9922A" }}>Send Payment To</p>
                      <p className="font-cinzel font-bold text-base" style={{ color: "#F0E6C8" }}>03107828683</p>
                      <p className="font-cinzel text-xs mt-1" style={{ color: "#9C8860" }}>Mehmood ul Hasan</p>
                      <p className="font-cinzel text-xs mt-1" style={{ color: "#9C8860" }}>EasyPaisa Account</p>
                      <div className="mt-3 pt-3" style={{ borderTop: "1px solid rgba(201,146,42,0.2)" }}>
                        <p className="text-xs" style={{ color: "#C8B896" }}>Amount to send: <span className="font-bold gold-shimmer font-cinzel">PKR {total.toLocaleString()}</span></p>
                      </div>
                    </div>

                    {/* Screenshot upload */}
                    <div>
                      <p className="font-cinzel text-[10px] tracking-widest uppercase mb-2" style={{ color: "#9C8860" }}>Upload Payment Screenshot *</p>
                      <label className="flex flex-col items-center justify-center cursor-pointer transition-all"
                        style={{ border: `1px dashed ${errors.screenshot ? "#E05A5A" : "rgba(201,146,42,0.4)"}`, background: "#1C1710", padding: "24px", gap: "8px" }}>
                        {screenshotPreview ? (
                          <img src={screenshotPreview} alt="Payment screenshot" className="max-h-32 object-contain" />
                        ) : (
                          <>
                            <svg width="28" height="28" fill="none" stroke="#C9922A" strokeWidth="1.5" viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4M17 8l-5-5-5 5M12 3v12"/></svg>
                            <span className="font-cinzel text-xs tracking-widest uppercase" style={{ color: "#9C8860" }}>Tap to upload screenshot</span>
                          </>
                        )}
                        <input type="file" accept="image/*" className="hidden" onChange={e => handleScreenshot(e.target.files?.[0] || null)} />
                      </label>
                      {screenshotPreview && (
                        <button onClick={() => handleScreenshot(null)} className="mt-2 font-cinzel text-[10px] tracking-widest uppercase" style={{ color: "#E05A5A" }}>Remove</button>
                      )}
                      {errors.screenshot && <p className="text-xs mt-1" style={{ color: "#E05A5A" }}>{errors.screenshot}</p>}
                    </div>
                  </div>
                )}
              </div>

              <div className="flex gap-3">
                <button onClick={() => setStep("details")} className="flex-1 font-cinzel text-xs tracking-widest uppercase py-3 transition-all"
                  style={{ border: "1px solid rgba(201,146,42,0.3)", color: "#9C8860" }}>
                  ← Back
                </button>
                <button onClick={handleSubmit} className="flex-1 font-cinzel text-xs tracking-widest uppercase py-3 transition-all"
                  style={{ background: "#C9922A", color: "#09080A" }}
                  onMouseEnter={e => (e.currentTarget as HTMLElement).style.background = "#E8B84B"}
                  onMouseLeave={e => (e.currentTarget as HTMLElement).style.background = "#C9922A"}>
                  Place Order →
                </button>
              </div>
            </div>
          )}

          {/* ── STEP 3: Confirmation ── */}
          {step === "confirm" && (
            <div className="flex flex-col items-center gap-6 py-4 text-center">
              <div className="w-16 h-16 rounded-full flex items-center justify-center" style={{ background: "rgba(201,146,42,0.15)", border: "1px solid #C9922A" }}>
                <svg width="28" height="28" fill="none" stroke="#C9922A" strokeWidth="2" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
              </div>
              <div>
                <h3 className="font-cinzel font-black text-xl tracking-widest uppercase mb-2" style={{ color: "#F0E6C8" }}>Order Placed!</h3>
                <p className="text-sm leading-relaxed" style={{ color: "#9C8860" }}>
                  Thank you, <span style={{ color: "#C9922A" }}>{form.name}</span>. Your order has been received.
                </p>
              </div>

              <div className="w-full p-5 text-left" style={{ background: "#1C1710", border: "1px solid rgba(201,146,42,0.2)" }}>
                <p className="font-cinzel text-[10px] tracking-widest uppercase mb-3" style={{ color: "#9C8860" }}>Order Details</p>
                <div className="flex flex-col gap-1 text-xs" style={{ color: "#C8B896" }}>
                  <p><span style={{ color: "#9C8860" }}>Name:</span> {form.name}</p>
                  <p><span style={{ color: "#9C8860" }}>Phone:</span> {form.phone}</p>
                  <p><span style={{ color: "#9C8860" }}>Address:</span> {form.address}, {form.city}</p>
                  <p><span style={{ color: "#9C8860" }}>Payment:</span> {payment === "cod" ? "Cash on Delivery" : "EasyPaisa Advance"}</p>
                  <p><span style={{ color: "#9C8860" }}>Total:</span> <span className="font-cinzel font-bold" style={{ color: "#C9922A" }}>PKR {total.toLocaleString()}</span></p>
                </div>
              </div>

              <div className="p-4 w-full" style={{ background: "rgba(201,146,42,0.08)", border: "1px solid rgba(201,146,42,0.2)" }}>
                <p className="text-xs leading-relaxed" style={{ color: "#C8B896" }}>
                  {payment === "cod"
                    ? "We will contact you on your number to confirm delivery. Expected delivery: 2–4 business days."
                    : "We have received your payment screenshot. Your order will be dispatched within 24 hours."}
                </p>
              </div>

              <p className="text-xs" style={{ color: "#9C8860" }}>For queries, contact us on WhatsApp: <span style={{ color: "#C9922A" }}>03107828683</span></p>

              <button onClick={onSuccess} className="w-full font-cinzel text-xs tracking-widest uppercase py-3 transition-all"
                style={{ background: "#C9922A", color: "#09080A" }}
                onMouseEnter={e => (e.currentTarget as HTMLElement).style.background = "#E8B84B"}
                onMouseLeave={e => (e.currentTarget as HTMLElement).style.background = "#C9922A"}>
                Continue Shopping
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════
   MAIN APP
═══════════════════════════════════════ */
export default function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeFilter, setActiveFilter] = useState("All");
  const [scrolled, setScrolled] = useState(false);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [cartOpen, setCartOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [cartBounce, setCartBounce] = useState(false);

  useReveal();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const addToCart = useCallback((product: Product, qty: number, size: string) => {
    setCart(prev => {
      const existing = prev.find(i => i.product.id === product.id && i.size === size);
      if (existing) return prev.map(i => i.product.id === product.id && i.size === size ? { ...i, qty: i.qty + qty } : i);
      return [...prev, { product, qty, size }];
    });
    setCartBounce(true);
    setTimeout(() => setCartBounce(false), 450);
  }, []);

  const updateCart = useCallback((id: number, size: string, qty: number) => {
    if (qty <= 0) setCart(prev => prev.filter(i => !(i.product.id === id && i.size === size)));
    else setCart(prev => prev.map(i => i.product.id === id && i.size === size ? { ...i, qty } : i));
  }, []);

  const cartCount = cart.reduce((s, i) => s + i.qty, 0);
  const filtered = activeFilter === "All" ? products : products.filter(p => p.family === activeFilter);

  return (
    <div className="min-h-screen" style={{ background: "#09080A", color: "#F0E6C8" }}>

      {/* ── NAV ── */}
      <nav className="fixed top-0 left-0 right-0 z-40 flex items-center justify-between px-6 md:px-14 py-4 transition-all duration-300"
        style={{ background: scrolled ? "rgba(9,8,10,0.92)" : "transparent", backdropFilter: scrolled ? "blur(14px)" : "none", borderBottom: scrolled ? "1px solid rgba(201,146,42,0.18)" : "none" }}>
        <div className="flex flex-col leading-none">
          <span className="font-cinzel font-black text-xl tracking-widest gold-shimmer">SULTAN</span>
          <span className="font-cinzel text-[10px] tracking-[0.35em] uppercase" style={{ color: "#C9922A" }}>Fragrances</span>
        </div>

        <ul className="hidden md:flex gap-8 font-cinzel text-xs tracking-widest uppercase" style={{ color: "#9C8860" }}>
          {["Home", "Collection", "Contact"].map(l => (
            <li key={l}><a href={`#${l.toLowerCase()}`} className="nav-link hover:text-amber-400 transition-colors">{l}</a></li>
          ))}
        </ul>

        <div className="flex items-center gap-4">
          {/* Cart button */}
          <button onClick={() => setCartOpen(true)} className={`relative ${cartBounce ? "cart-bounce" : ""}`} style={{ color: "#C9922A" }}>
            <svg width="22" height="22" fill="none" stroke="currentColor" strokeWidth="1.8" viewBox="0 0 24 24"><path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4zM3 6h18M16 10a4 4 0 01-8 0"/></svg>
            {cartCount > 0 && (
              <span className="absolute -top-2 -right-2 w-5 h-5 flex items-center justify-center font-cinzel text-[9px] font-bold rounded-full" style={{ background: "#C9922A", color: "#09080A" }}>{cartCount}</span>
            )}
          </button>

          <a href="#collection" className="hidden md:inline-block font-cinzel text-xs tracking-widest uppercase px-5 py-2 transition-all"
            style={{ border: "1px solid #C9922A", color: "#C9922A" }}
            onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "#C9922A"; (e.currentTarget as HTMLElement).style.color = "#09080A"; }}
            onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "transparent"; (e.currentTarget as HTMLElement).style.color = "#C9922A"; }}>
            Shop Now
          </a>

          <button className="md:hidden" onClick={() => setMenuOpen(!menuOpen)} style={{ color: "#C9922A" }}>
            <svg width="24" height="24" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              {menuOpen ? <path strokeLinecap="round" d="M6 18L18 6M6 6l12 12" /> : <path strokeLinecap="round" d="M4 6h16M4 12h16M4 18h16" />}
            </svg>
          </button>
        </div>
      </nav>

      {menuOpen && (
        <div className="fixed inset-0 z-40 flex flex-col items-center justify-center gap-8 font-cinzel text-sm tracking-widest uppercase" style={{ background: "rgba(9,8,10,0.97)" }}>
          {["Home", "Collection", "Contact"].map(l => (
            <a key={l} href={`#${l.toLowerCase()}`} onClick={() => setMenuOpen(false)} style={{ color: "#C9922A" }}>{l}</a>
          ))}
        </div>
      )}

      {/* ── HERO ── */}
      <section id="home" className="relative min-h-screen flex items-center overflow-hidden">
        <img src={sultanHero} alt="Sultan Fragrances" className="absolute inset-0 w-full h-full object-cover" style={{ opacity: 0.9 }} />
        <div className="absolute inset-0" style={{ background: "linear-gradient(120deg, rgba(9,8,10,0.72) 0%, rgba(9,8,10,0.35) 50%, rgba(9,8,10,0.82) 100%)" }} />
        <div className="absolute bottom-0 left-0 right-0 h-32" style={{ background: "linear-gradient(to top, #09080A, transparent)" }} />

        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          {[{ size: 130, top: "14%", left: "5%", delay: "0s" }, { size: 80, top: "72%", left: "7%", delay: "1.5s" }, { size: 65, top: "38%", left: "89%", delay: "0.8s" }, { size: 105, top: "76%", left: "84%", delay: "2s" }].map((b, i) => (
            <div key={i} className="absolute rounded-full bokeh" style={{ width: b.size, height: b.size, top: b.top, left: b.left, background: "radial-gradient(circle, rgba(232,184,75,0.38) 0%, transparent 70%)", animationDelay: b.delay }} />
          ))}
        </div>

        <div className="relative z-10 px-8 md:px-20 max-w-2xl pt-24">
          <p className="reveal font-cinzel text-xs tracking-[0.4em] uppercase mb-4" style={{ color: "#E8B84B" }}>— Premium Impression Perfumes —</p>
          <h1 className="reveal font-cinzel font-black text-5xl md:text-7xl leading-none mb-6 uppercase" style={{ transitionDelay: "0.1s" }}>
            <span className="gold-shimmer">Sultan</span><br />
            <span style={{ color: "#FFFFFF" }}>Fragrances</span>
          </h1>
          <p className="reveal text-base leading-relaxed mb-10" style={{ color: "#E8DCC8", maxWidth: "460px", transitionDelay: "0.2s" }}>
            Long-lasting impression fragrances inspired by the world's finest houses — crafted for every mood and moment.
          </p>
          <div className="reveal flex flex-wrap gap-4" style={{ transitionDelay: "0.3s" }}>
            <a href="#collection" className="font-cinzel text-xs tracking-widest uppercase px-8 py-3 transition-all" style={{ background: "#C9922A", color: "#09080A" }}
              onMouseEnter={e => (e.currentTarget as HTMLElement).style.background = "#E8B84B"}
              onMouseLeave={e => (e.currentTarget as HTMLElement).style.background = "#C9922A"}>
              Explore Collection
            </a>
          </div>
        </div>

        <div className="absolute bottom-12 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 opacity-50">
          <span className="font-cinzel text-[10px] tracking-widest uppercase" style={{ color: "#C9922A" }}>Scroll</span>
          <div className="w-px h-10" style={{ background: "linear-gradient(to bottom, #C9922A, transparent)" }} />
        </div>
      </section>

      {/* ── STATS ── */}
      <div className="py-12 px-6" style={{ background: "#110E0A", borderTop: "1px solid rgba(201,146,42,0.12)", borderBottom: "1px solid rgba(201,146,42,0.12)" }}>
        <div className="max-w-5xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-6 text-center stagger-children">
          {[{ num: "50+", label: "Fragrances" }, { num: "10K+", label: "Happy Customers" }, { num: "100%", label: "Long-Lasting" }, { num: "Free", label: "Nationwide Delivery" }].map(s => (
            <div key={s.label} className="reveal scale-in">
              <p className="font-cinzel font-bold text-3xl gold-shimmer">{s.num}</p>
              <p className="font-cinzel text-xs tracking-widest uppercase mt-1" style={{ color: "#9C8860" }}>{s.label}</p>
            </div>
          ))}
        </div>
      </div>

      {/* ── COLLECTION ── */}
      <section id="collection" className="py-24 px-6">
        <div className="max-w-6xl mx-auto">
          <Reveal className="text-center mb-14">
            <p className="font-cinzel text-xs tracking-[0.4em] uppercase mb-3" style={{ color: "#C9922A" }}>Our Collection</p>
            <h2 className="font-cinzel font-black text-4xl md:text-5xl uppercase mb-2" style={{ color: "#F0E6C8" }}>Signature Scents</h2>
            <GoldDivider />
            <p className="mt-3 text-sm leading-relaxed mx-auto" style={{ color: "#9C8860", maxWidth: "440px" }}>
              Impression fragrances inspired by iconic perfume houses — delivering the same experience at an honest price.
            </p>
          </Reveal>

          <Reveal className="flex flex-wrap gap-3 justify-center mb-12">
            {filters.map(f => (
              <button key={f} onClick={() => setActiveFilter(f)}
                className="font-cinzel text-xs tracking-widest uppercase px-4 py-2 transition-all"
                style={{ border: "1px solid", borderColor: activeFilter === f ? "#C9922A" : "rgba(201,146,42,0.25)", background: activeFilter === f ? "#C9922A" : "transparent", color: activeFilter === f ? "#09080A" : "#9C8860" }}>
                {f}
              </button>
            ))}
          </Reveal>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 stagger-children">
            {filtered.map(p => (
              <div key={p.id} className="product-card reveal group relative overflow-hidden cursor-pointer"
                style={{ background: "#110E0A", border: "1px solid rgba(201,146,42,0.15)" }}>
                {p.badge && (
                  <div className="absolute top-4 right-4 z-10 font-cinzel text-[10px] tracking-widest uppercase px-3 py-1" style={{ background: "#C9922A", color: "#09080A" }}>{p.badge}</div>
                )}
                <div className="relative overflow-hidden h-64" style={{ background: "#1C1710" }} onClick={() => setSelectedProduct(p)}>
                  <img src={p.img} alt={p.name} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
                  <div className="absolute inset-0" style={{ background: "linear-gradient(to top, rgba(9,8,10,0.7) 0%, transparent 60%)" }} />
                  <p className="absolute bottom-3 left-4 font-cinzel text-[10px] tracking-widest uppercase" style={{ color: "#C9922A" }}>{p.family}</p>
                  {/* View details overlay */}
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300" style={{ background: "rgba(9,8,10,0.45)" }}>
                    <span className="font-cinzel text-xs tracking-widest uppercase px-4 py-2" style={{ border: "1px solid #C9922A", color: "#F0E6C8" }}>View Details</span>
                  </div>
                </div>
                <div className="p-5">
                  <p className="text-xs tracking-widest uppercase mb-1" style={{ color: "#8B6214" }}>{p.type}</p>
                  <h3 className="font-cinzel font-bold text-lg tracking-wide mb-1 cursor-pointer hover:text-amber-400 transition-colors" style={{ color: "#F0E6C8" }} onClick={() => setSelectedProduct(p)}>{p.name}</h3>
                  <p className="text-xs mb-5 italic" style={{ color: "#9C8860" }}>{p.notes}</p>
                  <div className="flex items-center justify-between">
                    <span className="font-cinzel font-bold text-base" style={{ color: "#C9922A" }}>{p.price}</span>
                    <button onClick={() => addToCart(p, 1, p.sizes[1] || p.sizes[0])}
                      className="font-cinzel text-[10px] tracking-widest uppercase px-4 py-2 transition-all"
                      style={{ border: "1px solid #C9922A", color: "#C9922A" }}
                      onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "#C9922A"; (e.currentTarget as HTMLElement).style.color = "#09080A"; }}
                      onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "transparent"; (e.currentTarget as HTMLElement).style.color = "#C9922A"; }}>
                      Add to Cart
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── WHY US ── */}
      <section className="py-20 px-6" style={{ background: "#0D0B08", borderTop: "1px solid rgba(201,146,42,0.1)" }}>
        <div className="max-w-5xl mx-auto">
          <Reveal className="text-center mb-12">
            <p className="font-cinzel text-xs tracking-[0.4em] uppercase mb-3" style={{ color: "#C9922A" }}>Why Sultan</p>
            <h2 className="font-cinzel font-black text-3xl md:text-4xl uppercase" style={{ color: "#F0E6C8" }}>Crafted With Precision</h2>
            <GoldDivider />
          </Reveal>
          <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-6 stagger-children">
            {[
              { icon: "⏱", title: "Long Lasting", desc: "8–12 hours of full projection on skin and clothes" },
              { icon: "🧴", title: "Premium Oils", desc: "Imported fragrance concentrate — no dilution" },
              { icon: "✅", title: "100% Genuine", desc: "No fillers, no compromise on quality" },
              { icon: "🚚", title: "Pakistan Wide", desc: "Free delivery to every city across Pakistan" },
            ].map(f => (
              <div key={f.title} className="reveal p-6 text-center" style={{ background: "#1C1710", border: "1px solid rgba(201,146,42,0.12)" }}>
                <div className="text-3xl mb-3">{f.icon}</div>
                <p className="font-cinzel text-xs tracking-widest uppercase mb-2" style={{ color: "#C9922A" }}>{f.title}</p>
                <p className="text-xs leading-relaxed" style={{ color: "#9C8860" }}>{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── BOTTLE SECTION (visual) ── */}
      <section id="about" className="py-20 px-6" style={{ background: "#09080A" }}>
        <div className="max-w-6xl mx-auto grid md:grid-cols-2 gap-14 items-center">
          <Reveal variant="from-left" className="relative">
            <div className="relative float-anim" style={{ border: "1px solid rgba(201,146,42,0.28)" }}>
              <img src={sultanBottle} alt="Sultan premium perfume bottle" className="w-full object-cover" style={{ maxHeight: "520px", objectPosition: "center" }} />
              <div className="absolute inset-0" style={{ background: "linear-gradient(180deg, transparent 60%, rgba(9,8,10,0.4) 100%)" }} />
            </div>
            <div className="absolute -left-3 top-8 bottom-8 w-px" style={{ background: "linear-gradient(180deg, transparent, #C9922A, transparent)" }} />
            <div className="absolute -top-3 -right-3 w-8 h-8 border-t-2 border-r-2" style={{ borderColor: "#C9922A" }} />
          </Reveal>

          <Reveal variant="from-right">
            <p className="font-cinzel text-xs tracking-[0.4em] uppercase mb-4" style={{ color: "#C9922A" }}>Premium Quality</p>
            <h2 className="font-cinzel font-black text-4xl md:text-5xl uppercase leading-tight mb-6" style={{ color: "#F0E6C8" }}>
              For the<br /><span className="gold-shimmer">Discerning Soul</span>
            </h2>
            <div className="h-px mb-7" style={{ background: "linear-gradient(90deg, #C9922A, transparent)" }} />
            <p className="leading-relaxed mb-5 text-sm" style={{ color: "#C8B896" }}>
              Sultan Fragrances brings you premium impression scents at accessible prices. Each bottle is filled with high-concentration fragrance oil so you get real longevity — not a fleeting spritz.
            </p>
            <p className="leading-relaxed mb-8 text-sm" style={{ color: "#9C8860" }}>
              Every scent is inspiredby a legendary house but made our own — layered, lasting, and unmistakably Sultan.
            </p>
            <a href="#collection" className="inline-block font-cinzel text-xs tracking-widest uppercase px-8 py-3 transition-all"
              style={{ background: "#C9922A", color: "#09080A" }}
              onMouseEnter={e => (e.currentTarget as HTMLElement).style.background = "#E8B84B"}
              onMouseLeave={e => (e.currentTarget as HTMLElement).style.background = "#C9922A"}>
              Shop Now
            </a>
          </Reveal>
        </div>
      </section>

      {/* ── TESTIMONIALS (compact) ── */}
      <section className="py-16 px-6" style={{ background: "#0D0B08", borderTop: "1px solid rgba(201,146,42,0.08)" }}>
        <div className="max-w-5xl mx-auto">
          <Reveal className="text-center mb-10">
            <p className="font-cinzel text-xs tracking-[0.4em] uppercase mb-2" style={{ color: "#C9922A" }}>Reviews</p>
            <h2 className="font-cinzel font-black text-3xl uppercase" style={{ color: "#F0E6C8" }}>Customer Love</h2>
            <GoldDivider />
          </Reveal>
          <div className="grid md:grid-cols-3 gap-5 stagger-children">
            {[
              { name: "Ayesha R.", city: "Lahore", text: "Dior Sauvage impression lasts all day. Sultan is my go-to now." },
              { name: "Bilal M.", city: "Karachi", text: "Incredible quality at an honest price. Ordered three bottles and loved every one." },
              { name: "Sana K.", city: "Islamabad", text: "Premium packaging, rich scent, fast delivery. Highly recommend!" },
            ].map((t, i) => (
              <div key={i} className="reveal p-6 relative" style={{ background: "#110E0A", border: "1px solid rgba(201,146,42,0.12)" }}>
                <span className="absolute top-3 right-5 font-playfair text-5xl leading-none" style={{ color: "rgba(201,146,42,0.1)" }}>"</span>
                <div className="flex gap-0.5 mb-3">
                  {[...Array(5)].map((_, j) => <span key={j} className="text-sm" style={{ color: "#C9922A" }}>★</span>)}
                </div>
                <p className="text-xs leading-relaxed italic mb-4" style={{ color: "#C8B896" }}>"{t.text}"</p>
                <p className="font-cinzel text-xs font-bold" style={{ color: "#F0E6C8" }}>{t.name} <span className="font-normal" style={{ color: "#8B6214" }}>· {t.city}</span></p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CONTACT ── */}
      <section id="contact" className="py-20 px-6" style={{ background: "#09080A", borderTop: "1px solid rgba(201,146,42,0.1)" }}>
        <div className="max-w-4xl mx-auto text-center">
          <Reveal>
            <p className="font-cinzel text-xs tracking-[0.4em] uppercase mb-3" style={{ color: "#C9922A" }}>Get In Touch</p>
            <h2 className="font-cinzel font-black text-4xl uppercase mb-3" style={{ color: "#F0E6C8" }}>Order Your Scent</h2>
            <GoldDivider />
            <p className="text-sm mt-4 mb-10" style={{ color: "#9C8860" }}>We deliver nationwide across Pakistan. Reach us via WhatsApp or Instagram.</p>
          </Reveal>

          <div className="grid sm:grid-cols-3 gap-5 stagger-children">
            {[
              { icon: <svg viewBox="0 0 24 24" fill="currentColor" className="w-6 h-6"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/><path d="M12 0C5.373 0 0 5.373 0 12c0 2.127.558 4.122 1.532 5.855L0 24l6.335-1.51A11.94 11.94 0 0012 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 21.818a9.8 9.8 0 01-5.016-1.378l-.36-.214-3.742.983.998-3.648-.234-.374A9.78 9.78 0 012.182 12C2.182 6.57 6.57 2.182 12 2.182c5.43 0 9.818 4.388 9.818 9.818 0 5.43-4.388 9.818-9.818 9.818z"/></svg>, label: "WhatsApp", value: "03107828683", link: "https://wa.me/923107828683" },
              { icon: <svg viewBox="0 0 24 24" fill="currentColor" className="w-6 h-6"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"/></svg>, label: "Instagram", value: "@sultanfragrances", link: "#" },
              { icon: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-6 h-6"><path d="M17.657 16.657L13.414 20.9a2 2 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/><circle cx="12" cy="11" r="3"/></svg>, label: "Location", value: "Pakistan", link: "#" },
            ].map(c => (
              <a key={c.label} href={c.link}
                className="reveal flex flex-col items-center gap-4 p-7 transition-all"
                style={{ background: "#110E0A", border: "1px solid rgba(201,146,42,0.15)" }}
                onMouseEnter={e => { (e.currentTarget as HTMLElement).style.borderColor = "rgba(201,146,42,0.5)"; }}
                onMouseLeave={e => { (e.currentTarget as HTMLElement).style.borderColor = "rgba(201,146,42,0.15)"; }}>
                <div style={{ color: "#C9922A" }}>{c.icon}</div>
                <div className="text-center">
                  <p className="font-cinzel text-[10px] tracking-widest uppercase mb-1" style={{ color: "#9C8860" }}>{c.label}</p>
                  <p className="font-cinzel text-sm font-bold" style={{ color: "#F0E6C8" }}>{c.value}</p>
                </div>
              </a>
            ))}
          </div>
        </div>
      </section>

      {/* ── FOOTER ── */}
      <footer className="py-10 px-6 text-center" style={{ background: "#07060A", borderTop: "1px solid rgba(201,146,42,0.18)" }}>
        <div className="mb-3">
          <span className="font-cinzel font-black text-2xl tracking-widest gold-shimmer">SULTAN</span>
          <span className="font-cinzel text-xs tracking-[0.3em] uppercase ml-2" style={{ color: "#8B6214" }}>Fragrances</span>
        </div>
        <p className="font-cinzel text-xs tracking-widest uppercase" style={{ color: "#3A2E1C" }}>
          © 2024 Sultan Fragrances · All Rights Reserved · Pakistan
        </p>
      </footer>

      {/* ── MODALS ── */}
      {selectedProduct && (
        <ProductModal
          product={selectedProduct}
          onClose={() => setSelectedProduct(null)}
          onAddToCart={(p, qty, size) => { addToCart(p, qty, size); setSelectedProduct(null); }}
        />
      )}

      {cartOpen && (
        <CartPanel
          items={cart}
          onClose={() => setCartOpen(false)}
          onUpdate={updateCart}
          onCheckout={() => { setCartOpen(false); setCheckoutOpen(true); }}
        />
      )}

      {checkoutOpen && (
        <CheckoutModal
          items={cart}
          onClose={() => setCheckoutOpen(false)}
          onSuccess={() => { setCheckoutOpen(false); setCart([]); }}
        />
      )}
    </div>
  );
}
